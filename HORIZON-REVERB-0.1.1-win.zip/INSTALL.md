# HORIZON REVERB — install

VST3 · AU.

## Mac
1. Open `HORIZON-REVERB-mac.pkg`.
2. If macOS says it can't be opened (unidentified developer): **System Settings → Privacy & Security →** scroll down → **Open Anyway**. (Or right-click the file → Open.)
3. Click **Customize** to pick VST3 / AU, then Install.
4. Rescan plugins in your DAW. Logic: Settings → Plug-in Manager → Reset & Rescan Selection.

## Windows (zip, no installer)
1. Unzip `HORIZON-REVERB-win.zip`.
2. Copy the `HORIZON REVERB.vst3` folder into `C:\Program Files\Common Files\VST3`.
3. Rescan plugins in your DAW.

## Licence
Click **ACTIVATE** at the top of the plugin, paste your licence key (or a promo code) and press ACTIVATE.
Unregistered, everything works but the reverb pauses for 2 seconds every 45 seconds.
One activation covers VST3 and AU on that computer and stays valid there. If you uninstall and reinstall the plugin, activate again.

---

## 설치 (한국어)
**맥**: pkg 실행 → "확인되지 않은 개발자" 경고가 뜨면 **시스템 설정 → 개인정보 보호 및 보안 → 그래도 열기** → Customize에서 포맷 선택 → 설치 → DAW에서 플러그인 재스캔.

**윈도우**: zip 압축 해제 → `HORIZON REVERB.vst3` 폴더를 `C:\Program Files\Common Files\VST3` 에 복사 → DAW에서 재스캔.

**라이선스**: 플러그인 상단 **ACTIVATE** → 라이선스 키(또는 프로모션 코드) 붙여넣기 → ACTIVATE. 한 번 활성화하면 그 컴퓨터에서 계속 쓸 수 있고, 플러그인을 지우고 다시 설치하면 다시 활성화해야 합니다. 미등록 상태에선 45초마다 2초간 리버브가 빠집니다.

The macOS warning appears because the installer isn't paid-signed. The plugin is the same either way.

Credits: built with JUCE · Montserrat & JetBrains Mono (SIL OFL) · Earth map from Natural Earth (public domain).
