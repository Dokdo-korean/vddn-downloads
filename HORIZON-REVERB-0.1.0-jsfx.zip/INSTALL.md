# HORIZON REVERB — install

Free. VST3 · AU · JSFX (REAPER).

## Mac
1. Open `HORIZON-REVERB-mac.pkg`.
2. If macOS says it can't be opened (unidentified developer): **System Settings → Privacy & Security →** scroll down → **Open Anyway**. (Or right-click the file → Open.)
3. Click **Customize** to pick VST3 / AU / JSFX, then Install.
4. Rescan plugins in your DAW. Logic: Settings → Plug-in Manager → Reset & Rescan Selection.

## Windows
1. Run `HORIZON-REVERB-win.exe`.
2. If "Windows protected your PC" appears: **More info → Run anyway**.
3. Pick VST3 / JSFX, then Install. Rescan plugins in your DAW.

## REAPER only (no installer)
Unzip `HORIZON-REVERB-JSFX.zip` and copy the `VDDN` folder into REAPER's `Effects` folder
(Options → Show REAPER resource path). Then FX browser → JS → VDDN.

---

## 설치 (한국어)
**맥**: pkg 실행 → "확인되지 않은 개발자" 경고가 뜨면 **시스템 설정 → 개인정보 보호 및 보안 → 그래도 열기** → Customize에서 포맷 선택 → 설치 → DAW에서 플러그인 재스캔.

**윈도우**: exe 실행 → "Windows의 PC 보호" 경고가 뜨면 **추가 정보 → 실행** → 포맷 선택 → 설치.

**REAPER만**: JSFX zip을 풀어서 `VDDN` 폴더를 REAPER `Effects` 폴더에 넣기.

The warnings appear because the installer isn't paid-signed. The plugin is the same either way.

Credits: built with JUCE · Montserrat & JetBrains Mono (SIL OFL) · Earth map from Natural Earth (public domain).
